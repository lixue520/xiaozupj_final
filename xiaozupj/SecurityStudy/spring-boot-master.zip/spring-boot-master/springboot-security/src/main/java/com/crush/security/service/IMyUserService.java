package com.crush.security.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.crush.security.entity.MyUser;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lzw
 * @since 2021-05-12
 */
public interface IMyUserService extends IService<MyUser> {

}

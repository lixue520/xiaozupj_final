package com.hhz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hhz.domain.User;

public interface UserMapper extends BaseMapper<User> {
}

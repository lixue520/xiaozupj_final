package com.xzb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xzb.domain.User;

public interface UserMapper extends BaseMapper<User> {
}
